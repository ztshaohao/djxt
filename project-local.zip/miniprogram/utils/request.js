// 小程序网络请求封装：baseURL 与 app.js 保持一致
const BASE = 'http://localhost:3000';

function getToken() {
  return wx.getStorageSync('token') || '';
}

// 确保已登录：无 token 时 wx.login -> /api/auth/login 换 token
function ensureToken() {
  return new Promise((resolve, reject) => {
    const token = getToken();
    if (token) return resolve(token);
    wx.login({
      success: (r) => {
        wx.request({
          url: BASE + '/api/auth/login',
          method: 'POST',
          data: { code: r.code },
          success: (res) => {
            if (res.data && res.data.token) {
              wx.setStorageSync('token', res.data.token);
              resolve(res.data.token);
            } else {
              reject(new Error('登录失败'));
            }
          },
          fail: reject,
        });
      },
      fail: reject,
    });
  });
}

// 通用请求，自动带 token
function request(path, method, data) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: BASE + path,
      method,
      data,
      header: {
        Authorization: 'Bearer ' + getToken(),
        'Content-Type': 'application/json',
      },
      success: (res) => resolve(res.data),
      fail: reject,
    });
  });
}

// 获取当前登录用户的后台姓名（与账号一致）
function getMe() {
  return request('/api/records/me', 'GET');
}

// 本月录入统计：总数 + 红/黄/绿
function getMonthStats() {
  return request('/api/records/month-stats', 'GET');
}


// 上传图片（拍照 / 相册），返回可访问 URL
function uploadImage(tempFilePath) {
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: BASE + '/api/upload',
      filePath: tempFilePath,
      name: 'file',
      header: { Authorization: 'Bearer ' + getToken() },
      success: (res) => {
        try {
          const d = JSON.parse(res.data);
          if (d.url) resolve(d.url);
          else reject(new Error(d.error || '上传失败'));
        } catch (e) {
          reject(new Error('上传失败'));
        }
      },
      fail: reject,
    });
  });
}

module.exports = { BASE, getToken, ensureToken, request, uploadImage, getMe, getMonthStats };
