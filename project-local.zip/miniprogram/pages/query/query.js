const { ensureToken, request } = require('../../utils/request');

const ATTR_COLOR = { 红: '#f5222d', 黄: '#faad14', 绿: '#52c41a' };

Page({
  data: {
    list: [],
    total: 0,
    loading: false,
  },

  onShow() {
    this.load();
  },

  // 仅加载当日登记信息（后端已按当天过滤）
  async load() {
    if (this.data.loading) return;
    this.setData({ loading: true });
    try {
      await ensureToken();
      const res = await request('/api/records?pageSize=100', 'GET');
      if (res && res.list) {
        const list = res.list.map((r) => ({
          ...r,
          createdAt: new Date(r.createdAt).toLocaleString('zh-CN'),
          attrColor: ATTR_COLOR[r.personAttr] || '#999',
        }));
        this.setData({ list, total: res.total });
      }
    } catch (e) {
      wx.showToast({ title: '加载失败', icon: 'none' });
    } finally {
      this.setData({ loading: false });
    }
  },

  backHome() {
    wx.reLaunch({ url: '/pages/index/index' });
  },
});
