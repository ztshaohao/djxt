const { ensureToken, request, uploadImage, getMe } = require('../../utils/request');

function fmt(d) {
  const p = (n) => ('' + n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

Page({
  data: {
    name: '',
    nameEditable: false, // 有后台姓名则只读展示，首次可填
    nowTime: '',
    // 车辆线路：方块选择
    route: '',
    routeOptions: ['14南', '14北', '120路', '2路', '1路', '52路', '82路', '观光车', 'gb北车', 'td车'],
    // 人员信息：数字 / 图片 二选一（上下布局，选中突出）
    personMode: 'number',
    personImage: '',
    personNumber: '',
    // 是否为突出情况（人员信息栏内）
    isProminent: '否',
    // 现场照片（选填）
    scenePhoto: '',
    // 乘车站点
    boardPoint: '',
    alightPoint: '',
    // 是否移交（默认「是」，仅选是/否）
    needHandover: '是',
    // 人员属性：红 / 黄 / 绿
    personAttr: '',
    attrOptions: [
      { label: '红', color: '#f5222d' },
      { label: '黄', color: '#faad14' },
      { label: '绿', color: '#52c41a' },
    ],
    submitting: false,
  },

  async onLoad() {
    this.setData({ nowTime: fmt(new Date()) });
    try {
      await ensureToken();
      const me = await getMe();
      if (me && me.name) {
        this.setData({ name: me.name, nameEditable: false });
      } else {
        this.setData({ name: '', nameEditable: true });
      }
    } catch (e) {
      this.setData({ nameEditable: true });
    }
  },

  onInput(e) {
    const f = e.currentTarget.dataset.field;
    this.setData({ [f]: e.detail.value });
  },

  // 车辆线路：方块选择
  selectRoute(e) {
    this.setData({ route: e.currentTarget.dataset.val });
  },

  // 人员信息：数字 / 图片
  switchMode(e) {
    const m = e.currentTarget.dataset.mode;
    this.setData({ personMode: m, personImage: '', personNumber: '' });
  },
  async choosePersonImage() {
    await this.pickAndUpload('personImage');
  },
  async chooseScenePhoto() {
    await this.pickAndUpload('scenePhoto');
  },
  async pickAndUpload(field) {
    try {
      const r = await new Promise((resolve, reject) => {
        wx.chooseMedia({
          count: 1,
          mediaType: ['image'],
          sourceType: ['album', 'camera'],
          success: resolve,
          fail: reject,
        });
      });
      const temp = r.tempFiles[0].tempFilePath;
      wx.showLoading({ title: '上传中' });
      await ensureToken();
      const url = await uploadImage(temp);
      this.setData({ [field]: url });
      wx.showToast({ title: '已上传' });
    } catch (err) {
      wx.showToast({ title: '上传失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  // 是否移交（仅 是 / 否）
  chooseNeed(e) {
    this.setData({ needHandover: e.currentTarget.dataset.val });
  },
  // 是否突出情况
  chooseProminent(e) {
    this.setData({ isProminent: e.currentTarget.dataset.val });
  },

  // 人员属性
  chooseAttr(e) {
    this.setData({ personAttr: e.currentTarget.dataset.val });
  },

  backHome() {
    wx.reLaunch({ url: '/pages/index/index' });
  },

  async submit() {
    const d = this.data;
    if (!d.name) return wx.showToast({ title: '请填写姓名', icon: 'none' });
    if (!d.route) return wx.showToast({ title: '请选择车辆线路', icon: 'none' });
    if (d.personMode === 'image' && !d.personImage)
      return wx.showToast({ title: '请上传人员图片', icon: 'none' });
    if (d.personMode === 'number' && !d.personNumber)
      return wx.showToast({ title: '请填写人员数字', icon: 'none' });
    if (!d.boardPoint || !d.alightPoint)
      return wx.showToast({ title: '请填写上/下车站点', icon: 'none' });
    if (!d.personAttr) return wx.showToast({ title: '请选择人员属性', icon: 'none' });
    if (d.personNumber && !/^[A-Za-z0-9]{18}$/.test(d.personNumber))
      return wx.showToast({ title: '人员编号需为 18 位', icon: 'none' });
    if (d.submitting) return;

    this.setData({ submitting: true });
    wx.showLoading({ title: '提交中' });
    try {
      await ensureToken();
      const body = {
        name: d.name,
        route: d.route,
        person_image: d.personMode === 'image' ? d.personImage : '',
        person_number: d.personMode === 'number' ? d.personNumber : '',
        scene_photo: d.scenePhoto,
        board_point: d.boardPoint,
        alight_point: d.alightPoint,
        need_handover: d.needHandover,
        is_prominent: d.isProminent,
        person_attr: d.personAttr,
      };
      const res = await request('/api/records', 'POST', body);
      if (res && res.success) {
        wx.showToast({ title: '登记成功', icon: 'success' });
        setTimeout(() => {
          wx.reLaunch({ url: '/pages/index/index' });
        }, 600);
        this.setData({
          route: '',
          personMode: 'number',
          personImage: '',
          personNumber: '',
          isProminent: '否',
          scenePhoto: '',
          boardPoint: '',
          alightPoint: '',
          needHandover: '是',
          personAttr: '',
        });
      } else {
        wx.showToast({ title: (res && res.error) || '登记失败', icon: 'none' });
      }
    } catch (e) {
      wx.showToast({ title: '网络错误', icon: 'none' });
    } finally {
      this.setData({ submitting: false });
      wx.hideLoading();
    }
  },
});
