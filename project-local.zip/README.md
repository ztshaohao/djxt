# 信息录入小程序 + Web 管理后台

一个面向「车辆人员信息登记」的小程序方案：

- **微信小程序**：主页三模块入口（信息登记 / 已登记信息 / 本月登记统计-仅展示）→ 登记页（姓名取自后台只读、时间默认、车辆线路方块选择、人员信息数字/图片二选一+是否突出情况、是否移交（默认「是」，无移交人员编号）、人员属性红黄绿）+ 查询（**仅展示本人当日登记信息**，无检索）
- **Web 管理后台**（标题：**登记系统**）：管理员登录后查看全部登记、按姓名/手机号/线路/上下车站点/**人员属性**检索、分页（15/30/50）、CSV 导出、图片浮层预览与下载；并提供**数量核对 / 柱状图 / 统计分析（多维交叉，单表展示）** 功能；页头含标题、当前账号与退出登录；日期选择器为中文
- **后端 API**：Node.js + Express + Prisma + SQLite，统一服务两端

---

## 目录结构

```
.
├── server/          # 后端 API 服务（Node + Express + Prisma + SQLite）
├── miniprogram/     # 微信小程序（原生）
└── web-admin/       # Web 管理后台（Vue3 + Vite + Element Plus）
```

## 环境要求

- Node.js ≥ 18（已验证 22.x 可运行）
- 微信开发者工具（跑小程序用）

---

## 1. 启动后端

```bash
cd server
npm install
npm run start        # 首次启动会自动建表 + 写入默认管理员
```

启动后：

- 服务地址：`http://localhost:3000`
- 自动创建 `server/dev.db`（SQLite 数据库）
- 自动创建默认管理员：**账号 `admin` / 密码 `admin123`**（上线前请改 `server/src/config.js` 中的 `DEFAULT_ADMIN_*` 或环境变量）

健康检查：`GET http://localhost:3000/api/health`

> 真机/上线接入微信登录：在 `server/src/config.js` 配置 `WX_APPID` / `WX_SECRET` 后，小程序 `wx.login` 的 code 会真实换取 openid。本地未配置时进入「开发模式」，code 直接当 openid，方便联调。

---

## 2. 启动 Web 管理后台

开发模式（热更新）：

```bash
cd web-admin
npm install
npm run dev          # 默认 http://localhost:5173
```

生产构建：

```bash
npm run build
npm run preview      # 预览打包结果
```

打开 `http://localhost:5173` → 用 `admin / admin123` 登录 → 查看/搜索/导出全部录入信息。
后台调用后端地址在 `web-admin/src/api.js` 的 `BASE` 中配置（默认 `http://localhost:3000`）。

---

## 3. 运行微信小程序

1. 用**微信开发者工具**导入 `miniprogram/` 目录。
2. `project.config.json` 已设置：
   - `appid`: `touristappid`（游客模式，无需真实 AppID 即可本地调试）
   - `urlCheck`: `false`（不校验合法域名，允许访问 `http://localhost:3000`）
3. 如要真机预览或上线，请：
   - 改为你自己的 AppID
   - 在小程序后台配置**合法域名**为你的后端 HTTPS 地址
   - 修改 `miniprogram/utils/request.js` 与 `app.js` 里的 `BASE` / `baseURL` 为真实域名
4. 编译后即可看到：先进入**主页（三模块）** → 点「信息登记」或「已登记信息」进入子页，子页可返回主页；第三个模块「本月登记统计」仅展示本月总量与红/黄/绿数量。
5. 登记提交成功后会**自动返回主页**，可直接进行下一步操作。

> 小程序端调用后端地址统一在 `miniprogram/utils/request.js` 的 `BASE`。

---

## 4. 录入字段说明（`records` 表）

| 字段 | 说明 | 备注 |
|------|------|------|
| name | 录入人姓名 | **录入页只读展示**，取自后台该账号最近一次录入姓名；首次无记录时可填写 |
| createdAt | 提交时间 | 打开表单自动默认当前时间，提交时后端用服务器时间落库 |
| route | 车辆线路 | **必填**，录入页以方块选择：`14南/14北/120路/2路/1路/52路/82路/观光车/gb北车/td车` |
| personImage / personNumber | 人员信息 | **二选一且必填（上下布局，选中突出）**：① 上传图片 ② 数字编号（须 18 位，数字或字母组合）；均支持拍照/相册 |
| isProminent | 是否突出情况 | 位于人员信息栏内，**默认「否」**，选「是」即标记 |
| scenePhoto | 现场照片 | **选填**，支持拍照/相册 |
| boardPoint / alightPoint | 上车站点 / 下车站点 | **必填**，汉字（登记页用绿/红对比展示） |
| needHandover | 是否移交 | 仅「是 / 否」两项，**默认「是」**（已移除移交人员编号字段） |
| personAttr | 人员属性 | 红 / 黄 / 绿 三色块 |
| transferredAt | 数据传输完成时间 | 录入数据落库后由后端自动记录 |
| openid | 录入人标识 | 用于「只查自己」隔离 |

---

## 5. 接口清单

**小程序端（需用户 token）**

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/auth/login` | `wx.login` 的 code 换 token（开发模式 code 即 openid） |
| GET  | `/api/records/me` | 获取当前账号后台姓名（录入页只读展示用） |
| GET  | `/api/records/month-stats` | 本月录入总量 + 红/黄/绿数量（主页统计模块用） |
| POST | `/api/records` | 登记一条信息（route / 人员信息 / 上车站点 / 下车站点 为必填；是否移交默认「是」；现场照片选填；人员编号须 18 位） |
| GET  | `/api/records?page=&pageSize=` | 查询**仅本人「当日」**记录（已取消检索） |

**上传（需用户 token）**

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/upload` | 上传图片（multipart，`file` 字段），返回 URL；用于人员图片 / 现场照片 |

**后台端（需管理员 token）**

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/admin/login` | 管理员登录，返回 token 与 username |
| GET  | `/api/admin/records?keyword=&person_attr=&from=&to=&page=&pageSize=` | 全部记录列表 + 搜索/人员属性/时间过滤/分页（pageSize 支持 15/30/50） |
| GET  | `/api/admin/records/export?keyword=&person_attr=&from=&to=` | 导出 CSV（Excel 可直接打开，UTF-8 BOM） |
| GET  | `/api/admin/stats/summary?keyword=&person_attr=&from=&to=` | 数量核对：当前时间段内各录入人数量 + 各人员属性数量 |
| GET  | `/api/admin/stats/dist?dims=person,attr,route,board,alight&...` | 分布统计：按所选维度分别计数，用于柱状图 |
| GET  | `/api/admin/stats/values?dims=...&...` | 各维度的可选值（交叉分析里全选/取消全选用） |
| POST | `/api/admin/stats/cross` | 交叉分析：body `{ dims, values, keyword, person_attr, from, to }`，按所选维度取**交集**，返回单一汇总表 |
| GET  | `/api/admin/admins` | 管理员账号列表（含 `current` 当前登录账号） |
| POST | `/api/admin/admins` | 新增管理员，body `{ username, password }`（密码 ≥ 6 位，用户名不可重复） |
| DELETE | `/api/admin/admins/:id` | 删除管理员（不能删自己，至少保留 1 个账号） |

---

## 6. 管理员账号管理

系统提供 **三种方式** 增加管理员账号，任选其一即可。密码统一用 `bcrypt` 加盐哈希存储，数据库里看不到明文。

### 方式一：后台界面新增（最简单，推荐）

1. 用现有管理员登录后台（`http://localhost:5173`）
2. 顶部功能按钮行点 **「账号管理」**
3. 在弹窗上方输入 **用户名 + 密码（≥6 位）** → 点 **「新增账号」**
4. 下方表格列出所有账号，当前登录的账号带「当前登录」标签；可点 **删除** 移除多余账号

> 限制：不能删除「当前登录的账号」，系统始终至少保留 1 个管理员。

### 方式二：命令行脚本（忘记密码 / 服务器上用）

```bash
cd server
npm run create-admin -- 新用户名 新密码
# 例：npm run create-admin -- zhangsan 123456
```

- 账号**不存在** → 新增
- 账号**已存在** → 直接重置密码（可用来找回密码）
- 执行完会打印当前全部管理员列表

不传参数时，依次读取环境变量 `ADMIN_USERNAME` / `ADMIN_PASSWORD`，再退回 `server/src/config.js` 里的默认账号。

### 方式三：配置默认账号（仅首次启动生效）

首次启动后端时会自动创建默认管理员 `admin / admin123`，来源优先级：

```
环境变量 DEFAULT_ADMIN_USERNAME / DEFAULT_ADMIN_PASSWORD
        ↓（未设置时）
server/src/config.js 的 DEFAULT_ADMIN_USERNAME / DEFAULT_ADMIN_PASSWORD
```

> 上线前务必改掉默认密码，并同时修改 `JWT_SECRET`。

---

## 7. 部署

本仓库默认按**本地运行**配置：SQLite 数据库、前端直连 `http://localhost:3000`、小程序「不校验合法域名」，开箱即跑（见上文 1~3 节）。

需要上线时，请查看 **`部署方案.md`**，内含两套完整方案：

| 方案 | 适用 | 核心内容 |
|------|------|----------|
| **方案一：云服务器** | 有自己服务器/域名 | Nginx + Docker Compose（或 PM2）+ MySQL + HTTPS + 小程序合法域名配置 |
| **方案二：微信云开发** | 想免运维、免域名 | 微信**云托管**（Express 原样跑容器，推荐）与**云函数**（需 `serverless-http` 适配）两种做法及改造要点 |

配套配置文件在 `deploy/`：

```
deploy/
├── Dockerfile           # 后端镜像（云服务器 / 云托管通用）
├── docker-compose.yml   # MySQL + API + Nginx 一键编排
├── nginx.conf           # 静态托管 + /api、/uploads 反向代理
└── ecosystem.config.js  # PM2 进程配置（不用 Docker 时用）
server/.env.example      # 环境变量示例
```

上线前务必修改：`JWT_SECRET`、默认管理员密码，并配置真实 `WX_APPID` / `WX_SECRET`。

部署到服务器后，如需新增管理员，在服务器上执行：

```bash
cd server && npm run create-admin -- 用户名 密码
```

（Docker 部署则 `docker compose exec api npm run create-admin -- 用户名 密码`），或者直接在后台界面点「账号管理」新增。
