const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const prisma = require('../prisma');
const config = require('../config');
const requireRole = require('../middleware/auth');

const router = express.Router();

// 管理员登录
router.post('/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: '请输入账号和密码' });
  }
  const admin = await prisma.admin.findUnique({ where: { username } });
  if (!admin || !bcrypt.compareSync(password, admin.passwordHash)) {
    return res.status(401).json({ error: '账号或密码错误' });
  }
  const token = jwt.sign({ username, role: 'admin' }, config.JWT_SECRET, {
    expiresIn: '7d',
  });
  res.json({ token, username });
});

/* ===== 管理员账号管理 ===== */

// 账号列表
router.get('/admins', requireRole('admin'), async (req, res) => {
  try {
    const list = await prisma.admin.findMany({
      select: { id: true, username: true, createdAt: true },
      orderBy: { id: 'asc' },
    });
    res.json({ list, current: req.user.username });
  } catch (e) {
    res.status(500).json({ error: '查询失败：' + e.message });
  }
});

// 新增管理员
router.post('/admins', requireRole('admin'), async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: '请填写账号和密码' });
  if (String(password).length < 6) return res.status(400).json({ error: '密码长度至少 6 位' });
  try {
    const exist = await prisma.admin.findUnique({ where: { username: String(username) } });
    if (exist) return res.status(400).json({ error: '该账号已存在' });
    const admin = await prisma.admin.create({
      data: {
        username: String(username),
        passwordHash: bcrypt.hashSync(String(password), 10),
      },
    });
    res.json({ success: true, data: { id: admin.id, username: admin.username } });
  } catch (e) {
    res.status(500).json({ error: '新增失败：' + e.message });
  }
});

// 删除管理员（不能删自己 / 至少保留一个）
router.delete('/admins/:id', requireRole('admin'), async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const target = await prisma.admin.findUnique({ where: { id } });
    if (!target) return res.status(404).json({ error: '账号不存在' });
    if (target.username === req.user.username)
      return res.status(400).json({ error: '不能删除当前登录的账号' });
    const count = await prisma.admin.count();
    if (count <= 1) return res.status(400).json({ error: '至少保留一个管理员账号' });
    await prisma.admin.delete({ where: { id } });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: '删除失败：' + e.message });
  }
});

// 构造查询条件（关键词 + 时间范围 + 人员属性）
function buildWhere(query) {
  const keyword = (query.keyword || '').trim();
  const personAttr = (query.person_attr || '').trim();
  const from = query.from || '';
  const to = query.to || '';
  const where = {};
  if (keyword) {
    where.OR = [
      { name: { contains: keyword } },
      { route: { contains: keyword } },
      { boardPoint: { contains: keyword } },
      { alightPoint: { contains: keyword } },
      { personNumber: { contains: keyword } },
      { personAttr: { contains: keyword } },
    ];
  }
  if (personAttr) where.personAttr = { contains: personAttr };
  if (from || to) {
    where.createdAt = {};
    if (from) where.createdAt.gte = new Date(from);
    if (to) where.createdAt.lte = new Date(to + 'T23:59:59');
  }
  return where;
}

const COLUMNS = [
  'id', '姓名', '提交时间', '传输完成时间', '车辆线路', '人员信息', '现场照片',
  '上车站点', '下车站点', '是否移交', '是否突出', '人员属性', '录入人openid',
];

function toCsvRow(r) {
  const info = r.personImage ? `[图片] ${r.personImage}` : r.personNumber;
  return [
    r.id,
    r.name,
    new Date(r.createdAt).toLocaleString('zh-CN'),
    new Date(r.transferredAt).toLocaleString('zh-CN'),
    r.route,
    info,
    r.scenePhoto,
    r.boardPoint,
    r.alightPoint,
    r.needHandover,
    r.isProminent,
    r.personAttr,
    r.openid,
  ];
}

function buildCsv(records) {
  const esc = (v) => {
    const s = v == null ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const header = COLUMNS.join(',');
  const lines = records.map((r) => toCsvRow(r).map(esc).join(','));
  return '﻿' + [header, ...lines].join('\r\n');
}

// 列表（全部记录，支持关键词 + 人员属性 + 时间范围 + 分页 + 每页数量）
router.get('/records', requireRole('admin'), async (req, res) => {
  const where = buildWhere(req.query);
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const allowed = [15, 30, 50];
  let pageSize = parseInt(req.query.pageSize) || 15;
  if (!allowed.includes(pageSize)) pageSize = 15;

  try {
    const [list, total] = await Promise.all([
      prisma.record.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.record.count({ where }),
    ]);
    res.json({ list, total, page, pageSize });
  } catch (e) {
    res.status(500).json({ error: '查询失败：' + e.message });
  }
});

// 导出 CSV
router.get('/records/export', requireRole('admin'), async (req, res) => {
  const where = buildWhere(req.query);
  try {
    const records = await prisma.record.findMany({ where, orderBy: { createdAt: 'desc' } });
    const csv = buildCsv(records);
    const filename = `records_${new Date().toISOString().slice(0, 10)}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
    res.send(csv);
  } catch (e) {
    res.status(500).json({ error: '导出失败：' + e.message });
  }
});

// 数量核对：当前时间段内各录入人数量 + 各人员属性数量
router.get('/stats/summary', requireRole('admin'), async (req, res) => {
  const where = buildWhere(req.query);
  try {
    const [byPerson, byAttr, total] = await Promise.all([
      prisma.record.groupBy({ by: ['name'], where, _count: { _all: true } }),
      prisma.record.groupBy({ by: ['personAttr'], where, _count: { _all: true } }),
      prisma.record.count({ where }),
    ]);
    res.json({
      total,
      byPerson: byPerson.map((x) => ({ name: x.name, count: x._count._all })),
      byAttr: byAttr.map((x) => ({ attr: x.personAttr, count: x._count._all })),
    });
  } catch (e) {
    res.status(500).json({ error: '统计失败：' + e.message });
  }
});

// 分布统计：按所选维度（person/attr/route/board/alight）分别计数，用于柱状图与饼图
const DIM_FIELD = {
  person: 'name',
  attr: 'personAttr',
  route: 'route',
  board: 'boardPoint',
  alight: 'alightPoint',
};
router.get('/stats/dist', requireRole('admin'), async (req, res) => {
  const where = buildWhere(req.query);
  const dims = (req.query.dims || '')
    .split(',')
    .map((s) => s.trim())
    .filter((d) => DIM_FIELD[d]);
  try {
    const result = {};
    await Promise.all(
      dims.map(async (dim) => {
        const rows = await prisma.record.groupBy({
          by: [DIM_FIELD[dim]],
          where,
          _count: { _all: true },
        });
        result[dim] = rows.map((x) => ({ name: x[DIM_FIELD[dim]], value: x._count._all }));
      })
    );
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: '统计失败：' + e.message });
  }
});

// 各维度的可选值（用于交叉分析里的全选/取消全选）
router.get('/stats/values', requireRole('admin'), async (req, res) => {
  const where = buildWhere(req.query);
  const dims = (req.query.dims || '')
    .split(',')
    .map((s) => s.trim())
    .filter((d) => DIM_FIELD[d]);
  try {
    const recs = await prisma.record.findMany({ where });
    const result = {};
    for (const dim of dims) {
      const field = DIM_FIELD[dim];
      const set = new Set();
      for (const r of recs) {
        const v = r[field];
        if (v != null && v !== '') set.add(v);
      }
      result[dim] = Array.from(set);
    }
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: '取值失败：' + e.message });
  }
});

// 交叉分析：按所选维度做交集统计，返回单一汇总表
// body: { dims: ['route','person'], values: { route: [...], person: [...] }, keyword, person_attr, from, to }
router.post('/stats/cross', requireRole('admin'), async (req, res) => {
  const body = req.body || {};
  const dims = Array.isArray(body.dims) ? body.dims.filter((d) => DIM_FIELD[d]) : [];
  const values = body.values || {};
  const where = buildWhere({
    keyword: body.keyword,
    person_attr: body.person_attr,
    from: body.from,
    to: body.to,
  });
  try {
    const recs = await prisma.record.findMany({ where });
    const counter = new Map();
    for (const r of recs) {
      const row = {};
      let skip = false;
      for (const dim of dims) {
        const v = r[DIM_FIELD[dim]];
        const sel = values[dim];
        if (Array.isArray(sel) && sel.length && !sel.includes(v)) {
          skip = true;
          break;
        }
        row[dim] = v;
      }
      if (skip) continue;
      const key = dims.map((d) => String(row[d])).join('\u0001');
      const hit = counter.get(key);
      if (hit) hit.count += 1;
      else counter.set(key, { ...row, count: 1 });
    }
    const rows = Array.from(counter.values()).sort((a, b) => b.count - a.count);
    res.json({ rows, total: rows.reduce((s, r) => s + r.count, 0) });
  } catch (e) {
    res.status(500).json({ error: '交叉分析失败：' + e.message });
  }
});

module.exports = router;
