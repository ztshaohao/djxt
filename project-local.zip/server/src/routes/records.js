const express = require('express');
const prisma = require('../prisma');
const requireRole = require('../middleware/auth');

const router = express.Router();

// 当天零点
function startOfToday() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

// 获取当前登录用户的基本信息（姓名取自后台最近一次登记，与账号一致）
router.get('/me', requireRole('user'), async (req, res) => {
  try {
    const rec = await prisma.record.findFirst({
      where: { openid: req.user.openid },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ openid: req.user.openid, name: rec ? rec.name : '' });
  } catch (e) {
    res.status(500).json({ error: '获取信息失败：' + e.message });
  }
});

// 本月登记统计：总数量 + 红/黄/绿 数量（仅本人）
router.get('/month-stats', requireRole('user'), async (req, res) => {
  try {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const recs = await prisma.record.findMany({
      where: { openid: req.user.openid, createdAt: { gte: start } },
      select: { personAttr: true },
    });
    const stats = { total: recs.length, red: 0, yellow: 0, green: 0 };
    for (const r of recs) {
      if (r.personAttr === '红') stats.red++;
      else if (r.personAttr === '黄') stats.yellow++;
      else if (r.personAttr === '绿') stats.green++;
    }
    res.json(stats);
  } catch (e) {
    res.status(500).json({ error: '统计失败：' + e.message });
  }
});

// 登记一条信息（本人）
router.post('/', requireRole('user'), async (req, res) => {
  const openid = req.user.openid;
  const b = req.body || {};

  const {
    name,
    route,
    person_image,
    person_number,
    scene_photo,
    board_point,
    alight_point,
    need_handover,
    is_prominent,
    person_attr,
    created_at,
  } = b;

  // 必填项校验
  if (!route) return res.status(400).json({ error: '车辆线路为必填项' });
  if (!person_image && !person_number)
    return res.status(400).json({ error: '人员信息（图片或数字）为必填项，二选一' });
  if (!board_point || !alight_point)
    return res.status(400).json({ error: '上车站点 / 下车站点为必填项' });
  if (!person_attr) return res.status(400).json({ error: '请选择人员属性' });

  // 格式校验
  if (person_number && !/^[A-Za-z0-9]{18}$/.test(String(person_number)))
    return res.status(400).json({ error: '人员数字编号需为 18 位（数字或字母组合）' });

  try {
    const record = await prisma.record.create({
      data: {
        name: String(name || ''),
        route: String(route),
        personImage: person_image ? String(person_image) : null,
        personNumber: person_number ? String(person_number) : null,
        scenePhoto: scene_photo ? String(scene_photo) : null,
        boardPoint: String(board_point),
        alightPoint: String(alight_point),
        needHandover: String(need_handover || '是'), // 默认「是」
        isProminent: is_prominent === '是' ? '是' : '否',
        personAttr: String(person_attr),
        openid,
        createdAt: created_at ? new Date(created_at) : undefined,
        transferredAt: new Date(), // 数据传输完成时间
      },
    });
    res.json({ success: true, data: record });
  } catch (e) {
    res.status(500).json({ error: '登记失败：' + e.message });
  }
});

// 查询本人「当日」的登记信息（无检索，仅当天）
router.get('/', requireRole('user'), async (req, res) => {
  const openid = req.user.openid;
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const pageSize = Math.min(100, Math.max(1, parseInt(req.query.pageSize) || 20));

  const where = { openid, createdAt: { gte: startOfToday() } };

  try {
    const [list, total] = await Promise.all([
      prisma.record.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.record.count({ where }),
    ]);
    res.json({ list, total, page, pageSize });
  } catch (e) {
    res.status(500).json({ error: '查询失败：' + e.message });
  }
});

module.exports = router;
