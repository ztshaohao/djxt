// PM2 进程管理配置（不用 Docker 时的部署方式）
// 用法：pm2 start deploy/ecosystem.config.js --env production
module.exports = {
  apps: [
    {
      name: 'register-api',
      script: 'src/app.js',
      cwd: '/opt/register-system/server', // 改成你的实际部署目录
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        JWT_SECRET: 'please_change_to_a_long_random_string',
        WX_APPID: '',
        WX_SECRET: '',
        DEFAULT_ADMIN_USERNAME: 'admin',
        DEFAULT_ADMIN_PASSWORD: 'please_change_me',
        // 切 MySQL 时使用
        // DATABASE_URL: 'mysql://root:password@127.0.0.1:3306/register_system?charset=utf8mb4',
      },
    },
  ],
};
