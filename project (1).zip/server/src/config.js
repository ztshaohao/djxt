// 运行配置：可用环境变量覆盖，本地直接跑用默认值即可
module.exports = {
  PORT: process.env.PORT || 3000,
  JWT_SECRET: process.env.JWT_SECRET || 'dev_secret_change_me',
  // 微信小程序真实 AppID / Secret；留空则进入「开发模式」：
  // 小程序传来的 code 直接当作 openid 使用，方便本地调试。
  WX_APPID: process.env.WX_APPID || '',
  WX_SECRET: process.env.WX_SECRET || '',
  // 默认管理员（首次启动自动写入库），请上线前修改
  DEFAULT_ADMIN_USERNAME: process.env.DEFAULT_ADMIN_USERNAME || 'admin',
  DEFAULT_ADMIN_PASSWORD: process.env.DEFAULT_ADMIN_PASSWORD || 'admin123',
};
