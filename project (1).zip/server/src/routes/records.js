const express = require('express');
const prisma = require('../prisma');
const requireRole = require('../middleware/auth');

const router = express.Router();

// 获取当前登录用户的基本信息（姓名取自后台最近一次录入，与账号一致）
router.get('/me', requireRole('user'), async (req, res) => {
  try {
    const rec = await prisma.record.findFirst({
      where: { openid: req.user.openid },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ openid: req.user.openid, name: rec ? rec.name : '' });
  } catch (e) {
    res.status(500).json({ error: '获取信息失败：' + e.message });
  }
});

// 本月录入统计：总数量 + 红/黄/绿 数量（仅本人）
router.get('/month-stats', requireRole('user'), async (req, res) => {
  try {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const recs = await prisma.record.findMany({
      where: { openid: req.user.openid, createdAt: { gte: start } },
      select: { personAttr: true },
    });
    const stats = { total: recs.length, red: 0, yellow: 0, green: 0 };
    for (const r of recs) {
      if (r.personAttr === '红') stats.red++;
      else if (r.personAttr === '黄') stats.yellow++;
      else if (r.personAttr === '绿') stats.green++;
    }
    res.json(stats);
  } catch (e) {
    res.status(500).json({ error: '统计失败：' + e.message });
  }
});

// 录入一条信息（本人）
router.post('/', requireRole('user'), async (req, res) => {
  const openid = req.user.openid;
  const b = req.body || {};

  const {
    name,
    route,
    person_image,
    person_number,
    scene_photo,
    board_point,
    alight_point,
    need_handover,
    handover_person,
    is_prominent,
    reaction,
    person_attr,
    person_phone,
    created_at,
  } = b;

  // 必填项校验
  if (!route) return res.status(400).json({ error: '车辆线路为必填项' });
  if (!person_image && !person_number)
    return res.status(400).json({ error: '人员信息（图片或数字）为必填项，二选一' });
  if (!board_point || !alight_point)
    return res.status(400).json({ error: '上车站点 / 下车站点为必填项' });
  if (!need_handover) return res.status(400).json({ error: '请选择是否移交' });
  if (need_handover === '是' && !handover_person)
    return res.status(400).json({ error: '请填写移交人员' });
  if (!person_attr) return res.status(400).json({ error: '请选择人员属性' });

  // 格式校验
  if (person_phone && !/^1\d{10}$/.test(String(person_phone)))
    return res.status(400).json({ error: '手机号需为 11 位有效数字' });
  if (person_number && !/^[A-Za-z0-9]{18}$/.test(String(person_number)))
    return res.status(400).json({ error: '人员数字编号需为 18 位（数字或字母组合）' });
  if (handover_person && !/^[A-Za-z0-9]{6}$/.test(String(handover_person)))
    return res.status(400).json({ error: '移交人员信息需为 6 位' });

  try {
    const record = await prisma.record.create({
      data: {
        name: String(name || ''),
        route: String(route),
        personImage: person_image ? String(person_image) : null,
        personNumber: person_number ? String(person_number) : null,
        scenePhoto: scene_photo ? String(scene_photo) : null,
        boardPoint: String(board_point),
        alightPoint: String(alight_point),
        needHandover: String(need_handover),
        handoverPerson: handover_person ? String(handover_person) : null,
        isProminent: is_prominent === '是' ? '是' : '否',
        reaction: reaction ? String(reaction) : null,
        personAttr: String(person_attr),
        personPhone: person_phone ? String(person_phone) : null,
        openid,
        createdAt: created_at ? new Date(created_at) : undefined,
        transferredAt: new Date(), // 数据传输完成时间
      },
    });
    res.json({ success: true, data: record });
  } catch (e) {
    res.status(500).json({ error: '录入失败：' + e.message });
  }
});

// 检索联想：按 线路 / 姓名 / 人员编号 / 上车站点 / 下车站点 做模糊提示（仅本人数据）
router.get('/suggest', requireRole('user'), async (req, res) => {
  const keyword = (req.query.keyword || '').trim().toLowerCase();
  try {
    const recs = await prisma.record.findMany({
      where: { openid: req.user.openid },
      orderBy: { createdAt: 'desc' },
      take: 500,
    });
    const uniq = (arr) => Array.from(new Set(arr.filter((v) => v != null && v !== '')));
    const match = (v) => !keyword || String(v).toLowerCase().includes(keyword);
    const pick = (arr) => uniq(arr).filter(match).slice(0, 10);
    res.json({
      route: pick(recs.map((r) => r.route)),
      name: pick(recs.map((r) => r.name)),
      personNumber: pick(recs.map((r) => r.personNumber)),
      boardPoint: pick(recs.map((r) => r.boardPoint)),
      alightPoint: pick(recs.map((r) => r.alightPoint)),
    });
  } catch (e) {
    res.status(500).json({ error: '联想失败：' + e.message });
  }
});

// 查询本人录入的信息（关键词 + 分页）
router.get('/', requireRole('user'), async (req, res) => {
  const openid = req.user.openid;
  const keyword = (req.query.keyword || '').trim();
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const pageSize = Math.min(100, Math.max(1, parseInt(req.query.pageSize) || 20));

  const where = { openid };
  if (keyword) {
    where.OR = [
      { name: { contains: keyword } },
      { route: { contains: keyword } },
      { boardPoint: { contains: keyword } },
      { alightPoint: { contains: keyword } },
      { personPhone: { contains: keyword } },
      { personNumber: { contains: keyword } },
      { personAttr: { contains: keyword } },
    ];
  }

  try {
    const [list, total] = await Promise.all([
      prisma.record.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.record.count({ where }),
    ]);
    res.json({ list, total, page, pageSize });
  } catch (e) {
    res.status(500).json({ error: '查询失败：' + e.message });
  }
});

module.exports = router;
