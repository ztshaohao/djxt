const express = require('express');
const jwt = require('jsonwebtoken');
const config = require('../config');

const router = express.Router();

// 小程序登录：wx.login 拿 code -> 换 openid -> 发 token
// 开发模式（未配置 WX_APPID）下，code 直接当作 openid，便于本地联调
router.post('/login', async (req, res) => {
  const { code } = req.body || {};
  if (!code) {
    return res.status(400).json({ error: '缺少 code 参数' });
  }

  let openid;
  if (config.WX_APPID && config.WX_SECRET) {
    const url =
      `https://api.weixin.qq.com/sns/jscode2session` +
      `?appid=${config.WX_APPID}&secret=${config.WX_SECRET}` +
      `&js_code=${code}&grant_type=authorization_code`;
    try {
      const resp = await fetch(url);
      const data = await resp.json();
      if (data.errcode) {
        return res.status(400).json({ error: `微信登录失败: ${data.errmsg}` });
      }
      openid = data.openid;
    } catch (e) {
      return res.status(500).json({ error: '请求微信接口失败' });
    }
  } else {
    openid = String(code); // 开发模式兜底
  }

  const token = jwt.sign({ openid, role: 'user' }, config.JWT_SECRET, {
    expiresIn: '30d',
  });
  res.json({ token, openid });
});

module.exports = router;
