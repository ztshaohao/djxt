const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./config');
const prisma = require('./prisma');
const authRoutes = require('./routes/auth');
const recordRoutes = require('./routes/records');
const adminRoutes = require('./routes/admin');
const uploadRoutes = require('./routes/upload');

const app = express();
app.use(cors());
app.use(express.json());

// 静态托管上传的图片
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/records', recordRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/upload', uploadRoutes);

// 简易建表 + 种子管理员
async function bootstrap() {
  try {
    await prisma.$connect();
    const { execSync } = require('child_process');
    console.log('[prisma] 同步数据库结构...');
    execSync('npx prisma db push --skip-generate', { stdio: 'inherit' });
    require('./seed')(); // 写入默认管理员（不在此断开连接）
  } catch (e) {
    console.error('启动准备失败：', e.message);
  }
  app.listen(config.PORT, () => {
    console.log(`服务已启动: http://localhost:${config.PORT}`);
  });
}

bootstrap();
