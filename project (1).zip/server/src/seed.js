// 首次启动写入默认管理员（若库里还没有）
const prisma = require('./prisma');
const bcrypt = require('bcryptjs');
const config = require('./config');

async function seed() {
  const exist = await prisma.admin.findUnique({
    where: { username: config.DEFAULT_ADMIN_USERNAME },
  });
  if (!exist) {
    await prisma.admin.create({
      data: {
        username: config.DEFAULT_ADMIN_USERNAME,
        passwordHash: bcrypt.hashSync(config.DEFAULT_ADMIN_PASSWORD, 10),
      },
    });
    console.log(
      `已创建默认管理员 账号: ${config.DEFAULT_ADMIN_USERNAME}  密码: ${config.DEFAULT_ADMIN_PASSWORD}`
    );
  } else {
    console.log('管理员已存在，跳过初始化');
  }
}

module.exports = seed;

// 仅作为 `node src/seed.js` 单独运行时才断开连接，避免污染共享 client
if (require.main === module) {
  seed()
    .catch((e) => console.error(e))
    .finally(() => prisma.$disconnect());
}
