const jwt = require('jsonwebtoken');
const config = require('../config');

// 角色校验中间件：role 为 'user' | 'admin'
module.exports = function requireRole(role) {
  return function (req, res, next) {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    if (!token) {
      return res.status(401).json({ error: '未登录或缺少 token' });
    }
    try {
      const payload = jwt.verify(token, config.JWT_SECRET);
      if (role && payload.role !== role) {
        return res.status(403).json({ error: '无权限访问该资源' });
      }
      req.user = payload; // { openid } 或 { username }
      next();
    } catch (e) {
      return res.status(401).json({ error: 'token 无效或已过期' });
    }
  };
};
