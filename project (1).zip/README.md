# 信息录入小程序 + Web 管理后台

一个面向「车辆人员信息登记」的小程序方案：

- **微信小程序**：主页三模块入口（信息登记 / 已登记信息 / 本月登记统计-仅展示）→ 登记页（姓名取自后台只读、时间默认、车辆线路方块选择、人员信息数字/图片二选一+是否突出情况、现场照片选填、上/下车站点对比、是否移交→移交人员编号、反应情况、人员属性红黄绿）+ 查询（仅本人，支持线路/姓名/编号/上下车站点模糊联想）
- **Web 管理后台**（标题：**登记系统**）：管理员登录后查看全部登记、按姓名/手机号/线路/上下车站点/**人员属性**检索、分页（15/30/50）、CSV 导出、图片浮层预览与下载；并提供**数量核对 / 柱状图 / 统计分析（多维交叉，单表展示）** 功能；页头含标题、当前账号与退出登录；日期选择器为中文
- **后端 API**：Node.js + Express + Prisma + SQLite，统一服务两端

---

## 目录结构

```
.
├── server/          # 后端 API 服务（Node + Express + Prisma + SQLite）
├── miniprogram/     # 微信小程序（原生）
└── web-admin/       # Web 管理后台（Vue3 + Vite + Element Plus）
```

## 环境要求

- Node.js ≥ 18（已验证 22.x 可运行）
- 微信开发者工具（跑小程序用）

---

## 1. 启动后端

```bash
cd server
npm install
npm run start        # 首次启动会自动建表 + 写入默认管理员
```

启动后：

- 服务地址：`http://localhost:3000`
- 自动创建 `server/dev.db`（SQLite 数据库）
- 自动创建默认管理员：**账号 `admin` / 密码 `admin123`**（上线前请改 `server/src/config.js` 中的 `DEFAULT_ADMIN_*` 或环境变量）

健康检查：`GET http://localhost:3000/api/health`

> 真机/上线接入微信登录：在 `server/src/config.js` 配置 `WX_APPID` / `WX_SECRET` 后，小程序 `wx.login` 的 code 会真实换取 openid。本地未配置时进入「开发模式」，code 直接当 openid，方便联调。

---

## 2. 启动 Web 管理后台

开发模式（热更新）：

```bash
cd web-admin
npm install
npm run dev          # 默认 http://localhost:5173
```

生产构建：

```bash
npm run build
npm run preview      # 预览打包结果
```

打开 `http://localhost:5173` → 用 `admin / admin123` 登录 → 查看/搜索/导出全部录入信息。
后台调用后端地址在 `web-admin/src/api.js` 的 `BASE` 中配置（默认 `http://localhost:3000`）。

---

## 3. 运行微信小程序

1. 用**微信开发者工具**导入 `miniprogram/` 目录。
2. `project.config.json` 已设置：
   - `appid`: `touristappid`（游客模式，无需真实 AppID 即可本地调试）
   - `urlCheck`: `false`（不校验合法域名，允许访问 `http://localhost:3000`）
3. 如要真机预览或上线，请：
   - 改为你自己的 AppID
   - 在小程序后台配置**合法域名**为你的后端 HTTPS 地址
   - 修改 `miniprogram/utils/request.js` 与 `app.js` 里的 `BASE` / `baseURL` 为真实域名
4. 编译后即可看到：先进入**主页（三模块）** → 点「信息登记」或「已登记信息」进入子页，子页可返回主页；第三个模块「本月登记统计」仅展示本月总量与红/黄/绿数量。
5. 登记提交成功后会**自动返回主页**，可直接进行下一步操作。

> 小程序端调用后端地址统一在 `miniprogram/utils/request.js` 的 `BASE`。

---

## 4. 录入字段说明（`records` 表）

| 字段 | 说明 | 备注 |
|------|------|------|
| name | 录入人姓名 | **录入页只读展示**，取自后台该账号最近一次录入姓名；首次无记录时可填写 |
| createdAt | 提交时间 | 打开表单自动默认当前时间，提交时后端用服务器时间落库 |
| route | 车辆线路 | **必填**，录入页以方块选择：`14南/14北/120路/2路/1路/52路/82路/观光车/gb北车/td车` |
| personImage / personNumber | 人员信息 | **二选一且必填（上下布局，选中突出）**：① 上传图片 ② 数字编号（须 18 位，数字或字母组合）；均支持拍照/相册 |
| personPhone | 人员手机号 | **非必填**，位于人员信息下方；若填须为 11 位 |
| isProminent | 是否突出情况 | 位于人员信息栏内，**默认「否」**，选「是」即标记 |
| scenePhoto | 现场照片 | **选填**，支持拍照/相册 |
| boardPoint / alightPoint | 上车站点 / 下车站点 | **必填**，汉字（登记页用绿/红对比展示） |
| needHandover / handoverPerson | 是否移交 / 移交人员编号 | **必填**；选「是」才需填移交人员编号（须 6 位） |
| reaction | 反应情况 | 选填，汉字，位于「是否移交」之后 |
| personAttr | 人员属性 | 红 / 黄 / 绿 三色块 |
| transferredAt | 数据传输完成时间 | 录入数据落库后由后端自动记录 |
| openid | 录入人标识 | 用于「只查自己」隔离 |

---

## 5. 接口清单

**小程序端（需用户 token）**

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/auth/login` | `wx.login` 的 code 换 token（开发模式 code 即 openid） |
| GET  | `/api/records/me` | 获取当前账号后台姓名（录入页只读展示用） |
| GET  | `/api/records/month-stats` | 本月录入总量 + 红/黄/绿数量（主页统计模块用） |
| GET  | `/api/records/suggest?keyword=` | 检索联想：线路/姓名/人员编号/上下车站点的模糊提示（仅本人数据） |
| POST | `/api/records` | 登记一条信息（route / 人员信息 / 上车站点 / 下车站点 / 是否移交为必填；移交人员编号按是否移交条件必填；现场照片选填；手机号须 11 位、编号须 18 位、移交编号须 6 位） |
| GET  | `/api/records?keyword=&page=&pageSize=` | 查询**仅本人**记录 |

**上传（需用户 token）**

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/upload` | 上传图片（multipart，`file` 字段），返回 URL；用于人员图片 / 现场照片 |

**后台端（需管理员 token）**

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/admin/login` | 管理员登录，返回 token 与 username |
| GET  | `/api/admin/records?keyword=&person_attr=&from=&to=&page=&pageSize=` | 全部记录列表 + 搜索/人员属性/时间过滤/分页（pageSize 支持 15/30/50） |
| GET  | `/api/admin/records/export?keyword=&person_attr=&from=&to=` | 导出 CSV（Excel 可直接打开，UTF-8 BOM） |
| GET  | `/api/admin/stats/summary?keyword=&person_attr=&from=&to=` | 数量核对：当前时间段内各录入人数量 + 各人员属性数量 |
| GET  | `/api/admin/stats/dist?dims=person,attr,route,board,alight&...` | 分布统计：按所选维度分别计数，用于柱状图 |
| GET  | `/api/admin/stats/values?dims=...&...` | 各维度的可选值（交叉分析里全选/取消全选用） |
| POST | `/api/admin/stats/cross` | 交叉分析：body `{ dims, values, keyword, person_attr, from, to }`，按所选维度取**交集**，返回单一汇总表 |

---

## 6. 部署提示（本地运行版）

本方案默认**本地运行**，数据库用 SQLite、前端直连 `localhost:3000`。若后续要上云：

- 后端：部署到云服务器/云函数，数据库可切 MySQL（`prisma/schema.prisma` 改 `provider` 即可），用环境变量注入 `JWT_SECRET` / `WX_APPID` / `WX_SECRET`。
- 小程序：配置 HTTPS 合法域名。
- 后台：构建后由 Nginx 等静态托管，接口走同域或反向代理。
