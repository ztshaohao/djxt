<template>
  <div class="records">
    <!-- 页头 -->
    <header class="topbar">
      <div class="brand">📋 登记系统</div>
      <div class="user">
        <span class="uname">当前登录：{{ currentUser || '管理员' }}</span>
        <el-button size="small" type="danger" plain @click="onLogout">退出登录</el-button>
      </div>
    </header>

    <el-card class="panel" shadow="never">
      <!-- 检索区 -->
      <div class="filter-row">
        <el-input v-model="keyword" placeholder="姓名/线路/地点/手机号/移交人" style="width: 230px" @keyup.enter="onSearch" />
        <el-select v-model="personAttr" placeholder="人员属性" clearable style="width: 130px">
          <el-option label="红" value="红" />
          <el-option label="黄" value="黄" />
          <el-option label="绿" value="绿" />
        </el-select>
        <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          value-format="YYYY-MM-DD"
        />
        <el-button type="primary" @click="onSearch">查询</el-button>
        <el-button @click="onReset">重置</el-button>
      </div>

      <!-- 功能按钮（统一一排） -->
      <div class="action-row">
        <el-button type="warning" @click="openCheck">数量核对</el-button>
        <el-button type="success" @click="openBar">柱状图展示</el-button>
        <el-button type="info" @click="openCross">统计分析</el-button>
        <el-button type="primary" plain :loading="exporting" @click="onExport">导出 CSV</el-button>
      </div>

      <!-- 数据表 -->
      <el-table :data="list" v-loading="loading" stripe border class="grid">
        <el-table-column prop="createdAt" label="提交时间" width="160" />
        <el-table-column prop="name" label="姓名" width="90" />
        <el-table-column prop="route" label="车辆线路" width="100" />
        <el-table-column label="人员信息" width="110">
          <template #default="{ row }">
            <img v-if="row.personImage" :src="row.personImage" class="thumb" @click="openPreview(row.personImage)" />
            <span v-else>{{ row.personNumber }}</span>
          </template>
        </el-table-column>
        <el-table-column label="现场照片" width="90">
          <template #default="{ row }">
            <img v-if="row.scenePhoto" :src="row.scenePhoto" class="thumb" @click="openPreview(row.scenePhoto)" />
            <span v-else class="muted">—</span>
          </template>
        </el-table-column>
        <el-table-column prop="boardPoint" label="上车站点" width="110" />
        <el-table-column prop="alightPoint" label="下车站点" width="110" />
        <el-table-column prop="needHandover" label="是否移交" width="90" />
        <el-table-column prop="handoverPerson" label="移交人员编号" width="110" />
        <el-table-column prop="isProminent" label="是否突出" width="90">
          <template #default="{ row }">
            <el-tag v-if="row.isProminent === '是'" type="danger" effect="dark" size="small">是</el-tag>
            <span v-else class="muted">否</span>
          </template>
        </el-table-column>
        <el-table-column prop="reaction" label="反应情况" min-width="120" show-overflow-tooltip />
        <el-table-column label="人员属性" width="110">
          <template #default="{ row }">
            <span class="attr-cell">
              {{ row.personAttr }}
              <i class="sq" :style="{ background: attrColor(row.personAttr) }" />
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="personPhone" label="手机号" width="120" />
        <el-table-column prop="transferredAt" label="传输完成时间" width="165" />
      </el-table>

      <!-- 分页 + 每页数量 -->
      <div class="pager">
        <span class="page-size">
          每页
          <el-select v-model="pageSize" style="width: 90px" @change="onSizeChange">
            <el-option label="15 条" :value="15" />
            <el-option label="30 条" :value="30" />
            <el-option label="50 条" :value="50" />
          </el-select>
        </span>
        <el-pagination
          background
          layout="total, prev, pager, next"
          :total="total"
          :current-page="page"
          :page-size="pageSize"
          @current-change="onPage"
        />
      </div>
    </el-card>

    <!-- 图片预览（浮于上层，可下载） -->
    <el-dialog v-model="previewVisible" title="图片预览" width="640px" append-to-body>
      <div class="preview-box">
        <img :src="previewUrl" class="preview-img" />
      </div>
      <template #footer>
        <a :href="previewUrl" target="_blank" download>
          <el-button type="primary">下载图片</el-button>
        </a>
        <el-button @click="previewVisible = false">关闭</el-button>
      </template>
    </el-dialog>

    <!-- 数量核对 -->
    <el-dialog v-model="checkVisible" title="数量核对" width="720px">
      <div class="stat-block">
        <div class="stat-title">当前时间段登记总量：<b>{{ checkData.total }}</b></div>
        <el-row :gutter="20">
          <el-col :span="12">
            <div class="sub-title">各录入人数量</div>
            <el-table :data="checkData.byPerson" border size="small" max-height="300">
              <el-table-column prop="name" label="录入人" />
              <el-table-column prop="count" label="数量" width="100" />
            </el-table>
          </el-col>
          <el-col :span="12">
            <div class="sub-title">各人员属性数量</div>
            <el-table :data="checkData.byAttr" border size="small" max-height="300">
              <el-table-column label="人员属性" width="120">
                <template #default="{ row }">
                  <span class="attr-cell">
                    {{ row.attr }}
                    <i class="sq" :style="{ background: attrColor(row.attr) }" />
                  </span>
                </template>
              </el-table-column>
              <el-table-column prop="count" label="数量" width="100" />
            </el-table>
          </el-col>
        </el-row>
      </div>
    </el-dialog>

    <!-- 柱状图 -->
    <el-dialog v-model="barVisible" title="柱状图展示（各录入人登记数量）" width="760px" @close="closeBar">
      <div ref="barChartRef" style="width: 100%; height: 360px" />
    </el-dialog>

    <!-- 统计分析：多选维度交叉（交集） -->
    <el-dialog v-model="crossVisible" title="统计分析（多维交叉）" width="900px">
      <div class="cross-tools">
        <span class="cross-label">分析维度：</span>
        <el-checkbox-group v-model="crossDims" @change="onCrossDimChange">
          <el-checkbox v-for="o in CROSS_OPTIONS" :key="o.value" :value="o.value" :label="o.value">{{ o.label }}</el-checkbox>
        </el-checkbox-group>
      </div>

      <div v-for="dim in crossDims" :key="dim" class="dim-block">
        <div class="dim-head">
          <span class="dim-title">{{ dimLabel(dim) }}</span>
          <el-button size="small" type="primary" plain @click="selectAll(dim)">全选</el-button>
          <el-button size="small" plain @click="clearAll(dim)">取消全选</el-button>
        </div>
        <el-checkbox-group v-model="crossValues[dim]" class="dim-values">
          <el-checkbox v-for="v in crossAll[dim] || []" :key="v" :value="v" :label="v">{{ v }}</el-checkbox>
        </el-checkbox-group>
      </div>

      <div class="cross-actions">
        <el-button type="primary" @click="renderCross">生成表格</el-button>
        <span class="cross-total">合计：{{ crossTotal }} 条</span>
      </div>

      <el-table v-if="crossDims.length" :data="crossRows" border size="small" max-height="360" class="cross-table">
        <el-table-column v-for="d in crossDims" :key="d" :prop="d" :label="dimLabel(d)" />
        <el-table-column prop="count" label="数量" width="100" />
      </el-table>
      <div v-else class="muted center">请至少选择一个分析维度</div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue';
import { useRouter } from 'vue-router';
import * as echarts from 'echarts';
import { getRecords, exportRecords, getStatsSummary, getStatsDist, getStatsValues, getStatsCross } from '../api';

const ATTR_COLORS = { 红: '#f5222d', 黄: '#faad14', 绿: '#52c41a' };
const attrColor = (a) => ATTR_COLORS[a] || '#999';

const keyword = ref('');
const personAttr = ref('');
const dateRange = ref([]);
const page = ref(1);
const pageSize = ref(15);
const total = ref(0);
const list = ref([]);
const loading = ref(false);
const exporting = ref(false);
const router = useRouter();
const currentUser = ref(localStorage.getItem('adminUser') || '');

function fmt(d) {
  return new Date(d).toLocaleString('zh-CN');
}
function baseParams() {
  return {
    keyword: keyword.value,
    person_attr: personAttr.value,
    from: dateRange.value?.[0] || '',
    to: dateRange.value?.[1] || '',
  };
}

async function load() {
  loading.value = true;
  try {
    const data = await getRecords({ ...baseParams(), page: page.value, pageSize: pageSize.value });
    list.value = (data.list || []).map((r) => ({
      ...r,
      createdAt: fmt(r.createdAt),
      transferredAt: fmt(r.transferredAt),
    }));
    total.value = data.total || 0;
  } catch (e) {
    console.error(e);
  } finally {
    loading.value = false;
  }
}
function onSearch() {
  page.value = 1;
  load();
}
function onReset() {
  keyword.value = '';
  personAttr.value = '';
  dateRange.value = [];
  page.value = 1;
  load();
}
function onPage(p) {
  page.value = p;
  load();
}
function onSizeChange() {
  page.value = 1;
  load();
}
async function onExport() {
  exporting.value = true;
  try {
    await exportRecords(baseParams());
  } catch (e) {
    console.error(e);
  } finally {
    exporting.value = false;
  }
}

/* 图片预览 + 下载 */
const previewVisible = ref(false);
const previewUrl = ref('');
function openPreview(url) {
  previewUrl.value = url;
  previewVisible.value = true;
}

/* 数量核对 */
const checkVisible = ref(false);
const checkData = ref({ total: 0, byPerson: [], byAttr: [] });
async function openCheck() {
  checkData.value = await getStatsSummary(baseParams());
  checkVisible.value = true;
}

/* 柱状图 */
const barVisible = ref(false);
const barChartRef = ref(null);
let barChart = null;
async function openBar() {
  barVisible.value = true;
  const dist = await getStatsDist({ ...baseParams(), dims: 'person' });
  await nextTick();
  renderBar(dist.person || []);
}
function renderBar(data) {
  const el = barChartRef.value;
  if (!el) return;
  if (barChart) barChart.dispose();
  barChart = echarts.init(el);
  barChart.setOption({
    tooltip: { trigger: 'axis' },
    grid: { left: 40, right: 20, bottom: 60, top: 30 },
    xAxis: { type: 'category', data: data.map((d) => d.name), axisLabel: { interval: 0, rotate: 30 } },
    yAxis: { type: 'value', minInterval: 1 },
    series: [{ type: 'bar', data: data.map((d) => d.value), itemStyle: { color: '#07c160' }, barWidth: '45%' }],
  });
}
function closeBar() {
  if (barChart) {
    barChart.dispose();
    barChart = null;
  }
}

/* 统计分析：多选维度取交集，单表展示 */
const crossVisible = ref(false);
const crossDims = ref(['attr']);
const CROSS_OPTIONS = [
  { label: '人员属性', value: 'attr' },
  { label: '车辆线路', value: 'route' },
  { label: '上车站点', value: 'board' },
  { label: '下车站点', value: 'alight' },
  { label: '录入人', value: 'person' },
];
const crossAll = ref({});
const crossValues = ref({});
const crossRows = ref([]);
const crossTotal = ref(0);
const dimLabel = (d) =>
  ({ attr: '人员属性', route: '车辆线路', board: '上车站点', alight: '下车站点', person: '录入人' }[d] || d);

async function openCross() {
  crossVisible.value = true;
  await loadCrossValues();
  renderCross();
}
async function loadCrossValues() {
  const vals = await getStatsValues({ ...baseParams(), dims: crossDims.value.join(',') });
  crossAll.value = vals;
  const sel = {};
  crossDims.value.forEach((d) => {
    sel[d] = [...(vals[d] || [])]; // 默认全选
  });
  crossValues.value = sel;
}
function onCrossDimChange() {
  loadCrossValues().then(renderCross);
}
function selectAll(dim) {
  crossValues.value[dim] = [...(crossAll.value[dim] || [])];
  renderCross();
}
function clearAll(dim) {
  crossValues.value[dim] = [];
  renderCross();
}
async function renderCross() {
  if (!crossDims.value.length) {
    crossRows.value = [];
    crossTotal.value = 0;
    return;
  }
  const data = await getStatsCross({
    dims: crossDims.value,
    values: crossValues.value,
    ...baseParams(),
  });
  crossRows.value = data.rows || [];
  crossTotal.value = data.total || 0;
}

function onLogout() {
  localStorage.removeItem('adminToken');
  localStorage.removeItem('adminUser');
  router.push('/login');
}

onMounted(load);
</script>

<style scoped>
.records {
  max-width: 1320px;
  margin: 0 auto;
  padding: 0 16px 28px;
}
.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: linear-gradient(90deg, #07c160, #09a8a0);
  color: #fff;
  padding: 18px 26px;
  border-radius: 0 0 14px 14px;
  margin-bottom: 18px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
}
.brand {
  font-size: 21px;
  font-weight: 700;
  letter-spacing: 1px;
}
.user {
  display: flex;
  align-items: center;
  gap: 16px;
}
.uname {
  font-size: 14px;
  opacity: 0.95;
}
.panel {
  border-radius: 14px;
}
.filter-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
}
.action-row {
  display: flex;
  align-items: center;
  gap: 12px;
  margin: 18px 0 18px;
  padding-top: 16px;
  border-top: 1px solid #f0f0f0;
}
.grid {
  margin-top: 4px;
}
.muted {
  color: #bbb;
}
.attr-cell {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.sq {
  display: inline-block;
  width: 14px;
  height: 14px;
  border-radius: 3px;
  vertical-align: middle;
}
.thumb {
  width: 46px;
  height: 46px;
  border-radius: 6px;
  object-fit: cover;
  cursor: pointer;
  border: 1px solid #eee;
  transition: transform 0.15s;
}
.thumb:hover {
  transform: scale(1.08);
}
.preview-box {
  text-align: center;
}
.preview-img {
  max-width: 100%;
  max-height: 60vh;
  border-radius: 8px;
  border: 1px solid #eee;
}
.pager {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 18px;
  flex-wrap: wrap;
  gap: 12px;
}
.page-size {
  color: #666;
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.stat-block .stat-title {
  margin-bottom: 16px;
  font-size: 15px;
}
.sub-title {
  margin: 8px 0;
  font-weight: 600;
  color: #333;
}
.cross-tools {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 18px;
}
.cross-label {
  font-weight: 600;
}
.dim-block {
  border: 1px solid #ebeef5;
  border-radius: 10px;
  padding: 12px 14px;
  margin-bottom: 14px;
  background: #fafbfc;
}
.dim-head {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 10px;
}
.dim-title {
  font-weight: 700;
  font-size: 14px;
  min-width: 90px;
}
.dim-values {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 18px;
}
.cross-actions {
  display: flex;
  align-items: center;
  gap: 16px;
  margin: 18px 0 14px;
}
.cross-total {
  color: #666;
  font-size: 14px;
}
.cross-table {
  margin-top: 6px;
}
.center {
  text-align: center;
  padding: 40px 0;
}
</style>
