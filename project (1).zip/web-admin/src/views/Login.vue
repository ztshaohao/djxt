<template>
  <div class="login-wrap">
    <el-card class="login-card">
      <h2 class="title">登记系统登录</h2>
      <el-form @submit.prevent="onSubmit">
        <el-form-item label="账号">
          <el-input v-model="username" placeholder="默认 admin" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="password" type="password" show-password placeholder="默认 admin123" @keyup.enter="onSubmit" />
        </el-form-item>
        <el-button type="primary" :loading="loading" style="width: 100%" @click="onSubmit">登录</el-button>
        <p v-if="error" class="error">{{ error }}</p>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { adminLogin } from '../api';

const username = ref('admin');
const password = ref('');
const loading = ref(false);
const error = ref('');
const router = useRouter();

async function onSubmit() {
  error.value = '';
  if (!username.value || !password.value) {
    error.value = '请输入账号和密码';
    return;
  }
  loading.value = true;
  try {
    const data = await adminLogin(username.value, password.value);
    if (data.token) {
      localStorage.setItem('adminToken', data.token);
      localStorage.setItem('adminUser', data.username || username.value);
      router.push('/records');
    } else {
      error.value = data.error || '登录失败';
    }
  } catch (e) {
    error.value = '网络错误，请确认后端已启动';
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.login-wrap {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f0f2f5;
}
.login-card {
  width: 360px;
}
.title {
  text-align: center;
  margin-bottom: 20px;
}
.error {
  color: #f56c6c;
  margin-top: 10px;
  text-align: center;
}
</style>
