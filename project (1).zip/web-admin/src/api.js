import axios from 'axios';

const BASE = 'http://localhost:3000';
const client = axios.create({ baseURL: BASE });

function authHeaders() {
  const t = localStorage.getItem('adminToken');
  return t ? { Authorization: 'Bearer ' + t } : {};
}

export function adminLogin(username, password) {
  return client.post('/api/admin/login', { username, password }).then((r) => r.data);
}

export function getRecords(params) {
  return client
    .get('/api/admin/records', { params, headers: authHeaders() })
    .then((r) => r.data);
}

// 数量核对：当前时间段内各录入人数量 + 各人员属性数量
export function getStatsSummary(params) {
  return client
    .get('/api/admin/stats/summary', { params, headers: authHeaders() })
    .then((r) => r.data);
}

// 分布统计：按所选维度计数（person/attr/route/board/alight），用于柱状图
export function getStatsDist(params) {
  return client
    .get('/api/admin/stats/dist', { params, headers: authHeaders() })
    .then((r) => r.data);
}

// 各维度可选值（交叉分析里的全选/取消全选用）
export function getStatsValues(params) {
  return client
    .get('/api/admin/stats/values', { params, headers: authHeaders() })
    .then((r) => r.data);
}

// 交叉分析：多选维度取交集，返回单一汇总表
export function getStatsCross(payload) {
  return client
    .post('/api/admin/stats/cross', payload, { headers: authHeaders() })
    .then((r) => r.data);
}

// 带鉴权的 CSV 导出（fetch + blob 下载，可带 header）
export async function exportRecords(params) {
  const t = localStorage.getItem('adminToken');
  const qs = new URLSearchParams(params).toString();
  const resp = await fetch(`${BASE}/api/admin/records/export?${qs}`, {
    headers: { Authorization: 'Bearer ' + t },
  });
  if (!resp.ok) throw new Error('导出失败');
  const blob = await resp.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `records_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
