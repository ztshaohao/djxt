import { createRouter, createWebHashHistory } from 'vue-router';
import Login from '../views/Login.vue';
import Records from '../views/Records.vue';

const routes = [
  { path: '/', redirect: '/records' },
  { path: '/login', component: Login },
  { path: '/records', component: Records, meta: { auth: true } },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

router.beforeEach((to) => {
  if (to.meta.auth && !localStorage.getItem('adminToken')) {
    return '/login';
  }
});

export default router;
