const { ensureToken } = require('./utils/request');

App({
  globalData: {
    // 本地联调地址；真机/上线请改为你的 HTTPS 域名
    baseURL: 'http://localhost:3000',
  },
  onLaunch() {
    // 启动时确保拿到登录 token（开发模式直接用 wx.login 的 code 当 openid）
    ensureToken().catch(() => {
      wx.showToast({ title: '登录失败，请检查后端', icon: 'none' });
    });
  },
});
