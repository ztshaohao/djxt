const { ensureToken, request, getSuggest } = require('../../utils/request');

const ATTR_COLOR = { 红: '#f5222d', 黄: '#faad14', 绿: '#52c41a' };

// 联想分组：车辆线路 / 姓名 / 人员编号 / 上下车站点
const SUGGEST_GROUPS = [
  { key: 'route', label: '车辆线路' },
  { key: 'name', label: '姓名' },
  { key: 'personNumber', label: '人员编号' },
  { key: 'boardPoint', label: '上车站点' },
  { key: 'alightPoint', label: '下车站点' },
];

Page({
  data: {
    list: [],
    keyword: '',
    page: 1,
    pageSize: 20,
    total: 0,
    loading: false,
    suggestions: [],
    showSuggest: false,
  },

  onShow() {
    this.load();
  },

  // 输入时按 线路/姓名/编号/上下车站点 模糊提示
  async onSearchInput(e) {
    const v = e.detail.value;
    this.setData({ keyword: v });
    if (!v) {
      this.setData({ suggestions: [], showSuggest: false });
      return;
    }
    try {
      await ensureToken();
      const s = await getSuggest(v);
      const flat = [];
      SUGGEST_GROUPS.forEach((g) => {
        (s[g.key] || []).forEach((val) => flat.push({ group: g.label, value: val }));
      });
      this.setData({ suggestions: flat, showSuggest: flat.length > 0 });
    } catch (err) {
      // 联想失败不影响正常搜索
    }
  },

  onBlur() {
    setTimeout(() => this.setData({ showSuggest: false }), 250);
  },

  selectSuggest(e) {
    const v = e.currentTarget.dataset.val;
    this.setData({ keyword: v, showSuggest: false, page: 1 });
    this.load();
  },

  async onSearch() {
    this.setData({ page: 1, showSuggest: false });
    await this.load();
  },

  async load() {
    if (this.data.loading) return;
    this.setData({ loading: true });
    try {
      await ensureToken();
      const res = await request(
        `/api/records?keyword=${encodeURIComponent(this.data.keyword)}&page=${this.data.page}&pageSize=${this.data.pageSize}`,
        'GET'
      );
      if (res && res.list) {
        const list = res.list.map((r) => ({
          ...r,
          createdAt: new Date(r.createdAt).toLocaleString('zh-CN'),
          attrColor: ATTR_COLOR[r.personAttr] || '#999',
        }));
        this.setData({ list, total: res.total });
      }
    } catch (e) {
      wx.showToast({ title: '加载失败', icon: 'none' });
    } finally {
      this.setData({ loading: false });
    }
  },

  backHome() {
    wx.reLaunch({ url: '/pages/index/index' });
  },
});
