const { ensureToken, getMonthStats } = require('../../utils/request');

Page({
  data: {
    month: { total: 0, red: 0, yellow: 0, green: 0 },
    loadingStats: false,
  },
  onLoad() {
    ensureToken();
    this.loadStats();
  },
  onShow() {
    this.loadStats();
  },
  async loadStats() {
    this.setData({ loadingStats: true });
    try {
      const stats = await getMonthStats();
      if (stats) this.setData({ month: stats });
    } catch (e) {
      // 忽略统计失败，不影响主页使用
    } finally {
      this.setData({ loadingStats: false });
    }
  },
  goEntry() {
    wx.navigateTo({ url: '/pages/entry/entry' });
  },
  goQuery() {
    wx.navigateTo({ url: '/pages/query/query' });
  },
});
