// 录入人姓名本地默认：首次填写后保存，之后自动预填
const KEY = 'userName';

function getUserName() {
  return wx.getStorageSync(KEY) || '';
}

function setUserName(name) {
  wx.setStorageSync(KEY, name);
}

module.exports = { getUserName, setUserName };
